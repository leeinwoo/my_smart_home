package com.example.smart_home;

import android.util.Log;

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.VideoView;


public class TempActivity extends Activity{
    
    private TextView tv_temp, tv_humi;
    private EditText et_temp, et_humi;
    private ImageView btn_temp_plus, btn_temp_minus, btn_humi_plus, btn_humi_minus;
    
    
    private boolean automode = false;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);				
		setContentView(R.layout.temp_activity);
		
		tv_temp = (TextView)findViewById(R.id.value_temp);
		tv_humi = (TextView)findViewById(R.id.value_humi);
		
		et_temp = (EditText)findViewById(R.id.temp_value);
		et_humi = (EditText)findViewById(R.id.humi_value);	
		
		btn_temp_plus = (ImageView)findViewById(R.id.temp_plus);
		btn_temp_plus.setOnClickListener(mClickListener);		
		
		btn_temp_minus = (ImageView)findViewById(R.id.temp_minus);
		btn_temp_minus.setOnClickListener(mClickListener);		
		
		btn_humi_plus = (ImageView)findViewById(R.id.humi_plus);
		btn_humi_plus.setOnClickListener(mClickListener);		
		
		btn_humi_minus = (ImageView)findViewById(R.id.humi_minus);
		btn_humi_minus.setOnClickListener(mClickListener);		
		
		et_temp.setEnabled(false);
		et_humi.setEnabled(false);
		btn_temp_plus.setEnabled(false);
		btn_temp_minus.setEnabled(false);
		btn_humi_plus.setEnabled(false);
		btn_humi_minus.setEnabled(false);	
		
		ToggleButton toggle = (ToggleButton) findViewById(R.id.toggle_auto);
		toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
		    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		        if (isChecked) {
		            // The toggle is enabled
		        	et_temp.setEnabled(true);
		    		et_humi.setEnabled(true);
		    		btn_temp_plus.setEnabled(true);
		    		btn_temp_minus.setEnabled(true);
		    		btn_humi_plus.setEnabled(true);
		    		btn_humi_minus.setEnabled(true);
		    		new AutomodeTask().execute();
		        } else {
		            // The toggle is disabled
		        	et_temp.setEnabled(false);
		    		et_humi.setEnabled(false);
		    		btn_temp_plus.setEnabled(false);
		    		btn_temp_minus.setEnabled(false);
		    		btn_humi_plus.setEnabled(false);
		    		btn_humi_minus.setEnabled(false);	
		        }
		    }
		});

		new Thread(new runThread()).start();
	}	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}	
	
	public class RequestTask extends AsyncTask<String, Void, String> {		

		private String temp, humi;
	    protected String doInBackground(String... params) {
	        String responce = null;
	        try {
	        	String str = "request";
	            PrintWriter out = new PrintWriter(new BufferedWriter(
	                    new OutputStreamWriter(MainActivity.socket.getOutputStream())), true);
	            out.println(str);
	            out.flush();

	            InputStream input = MainActivity.socket.getInputStream();
	            int lockSeconds = 10*1000;

	            long lockThreadCheckpoint = System.currentTimeMillis();
	            int availableBytes = input.available();
	            while(availableBytes <=0 && (System.currentTimeMillis() < lockThreadCheckpoint + lockSeconds)){
	                try{Thread.sleep(10);}catch(InterruptedException ie){ie.printStackTrace();}
	                availableBytes = input.available();
	            }

	            byte[] buffer = new byte[availableBytes];
	            input.read(buffer, 0, availableBytes);
	            responce = new String(buffer);

	            //out.close();
	            //input.close();
	            //socket.close();	            
	            StringTokenizer st = new StringTokenizer(responce, ",");
	            st.hasMoreTokens();
	            temp = st.nextToken();
	            st.hasMoreTokens();
	            humi = st.nextToken();	            
	        } catch (UnknownHostException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return responce;
	    }
	    protected void onPostExecute(String responce) {
	    	tv_temp.setText(temp);
	    	tv_humi.setText(humi);
	    }
	}
	public class AutomodeTask extends AsyncTask<String, Void, String> {		

	    protected String doInBackground(String... params) {
	        String responce = null;
	        try {
	        	String str = "Automode";
	        	str = str + "," + automode;
	            PrintWriter out = new PrintWriter(new BufferedWriter(
	                    new OutputStreamWriter(MainActivity.socket.getOutputStream())), true);
	            out.println(str);
	            out.flush();
            
	        } catch (UnknownHostException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return responce;
	    }
	    protected void onPostExecute(String responce) {
	    }
	}
	
	class runThread implements Runnable {
	    @Override
	    public void run() {	    	    	
	    	try {
	    		while (true){
	    			new RequestTask().execute();
	    			Thread.sleep(1000);
	    		}
			} catch (InterruptedException e) {}
	    }
	}
	
	ImageView.OnClickListener mClickListener = new View.OnClickListener() {		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub			
			switch (v.getId()){
			case R.id.temp_plus:
				String sp_temp = et_temp.getText().toString();
				float fp_temp = Float.valueOf(sp_temp).floatValue();
				fp_temp++;
				sp_temp = Float.toString(fp_temp);
				et_temp.setText(sp_temp);
				break;
			case R.id.temp_minus:	
				String sm_temp = et_temp.getText().toString();
				float fm_temp = Float.valueOf(sm_temp).floatValue();
				fm_temp--;
				sm_temp = Float.toString(fm_temp);
				et_temp.setText(sm_temp);
				break;
			case R.id.humi_plus:	
				String sp_humi = et_humi.getText().toString();
				float fp_humi = Float.valueOf(sp_humi).floatValue();
				fp_humi++;
				sp_humi = Float.toString(fp_humi);
				et_humi.setText(sp_humi);
				break;
			case R.id.humi_minus:	
				String sm_humi = et_humi.getText().toString();
				float fm_humi = Float.valueOf(sm_humi).floatValue();
				fm_humi--;
				sm_humi = Float.toString(fm_humi);
				et_humi.setText(sm_humi);
				break;
			}
		}
	};
}
