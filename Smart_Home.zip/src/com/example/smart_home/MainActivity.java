package com.example.smart_home;

import android.util.Log;

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

import com.example.smart_home.TempActivity.RequestTask;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.VideoView;

public class MainActivity extends Activity{
	
	private ImageView m2Image;
	private boolean AC_switch = false;
	
	public static Socket socket = null;
    private static final int SERVERPORT = 5000;
    private static final String SERVER_IP = "192.168.219.104";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);				
		setContentView(R.layout.activity_main);	
		
		findViewById(R.id.menu1).setOnClickListener(mClickListener);
		m2Image = (ImageView)findViewById(R.id.menu2);
		m2Image.setOnClickListener(mClickListener);
		findViewById(R.id.menu3).setOnClickListener(mClickListener);
		findViewById(R.id.menu4).setOnClickListener(mClickListener);			    

		new Thread(new ClientThread()).start();
	}		
	
	protected boolean AC_Toggle(boolean flag){		
		if(flag){
			m2Image.setImageResource(R.drawable.acoff);
		}
		else{
			m2Image.setImageResource(R.drawable.acon);			
		}
		return !flag;
	}	

	ImageView.OnClickListener mClickListener = new View.OnClickListener() {		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub			
			switch (v.getId()){
			case R.id.menu1:				
				Intent i1 = new Intent(MainActivity.this, WebActivity.class);	    
			    startActivity(i1);
				break;
			case R.id.menu2:				
				new AcContolTask().execute();
				break;
			case R.id.menu3:
				Intent i2 = new Intent(MainActivity.this, TempActivity.class);				
			    startActivity(i2);			   
				break;
			case R.id.menu4:
				break;
			}
		}
	};
	
	class ClientThread implements Runnable {

	    @Override
	    public void run() {
	        try {
	            InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
	            socket = new Socket(serverAddr, SERVERPORT);
	            
	        } catch (UnknownHostException e1) {
	            e1.printStackTrace();
	        } catch (IOException e1) {
	            e1.printStackTrace();
	        }

	    }

	}	
	
	public class AcContolTask extends AsyncTask<String, Void, String> {		

	    protected String doInBackground(String... params) {
	        String responce = null;
	        try {
	        	String str = "ac";
	            PrintWriter out = new PrintWriter(new BufferedWriter(
	                    new OutputStreamWriter(MainActivity.socket.getOutputStream())), true);
	            out.println(str);
	            out.flush();    
	        } catch (UnknownHostException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return responce;
	    }
	    protected void onPostExecute(String responce) {
	    	AC_switch = AC_Toggle(AC_switch);
	    }
	}	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
